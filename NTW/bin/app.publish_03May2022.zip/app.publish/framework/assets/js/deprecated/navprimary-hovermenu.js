function navprimary() {
    // Do nothing!
    }